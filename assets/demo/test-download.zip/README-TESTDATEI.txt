DEMO / TESTDATEI

Keine installierbare Minecraft-Mod.
Diese ZIP testet nur den Downloadablauf der AkameDevelopment-Website.
Nicht in den mods-Ordner legen.
