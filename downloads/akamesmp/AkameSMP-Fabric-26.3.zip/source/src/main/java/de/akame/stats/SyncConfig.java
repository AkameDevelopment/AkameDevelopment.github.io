package de.akame.stats;

import com.google.gson.*;
import java.io.*;
import java.net.URI;
import java.nio.file.*;

final class SyncConfig {
    String endpoint = "https://wycdpuzlbivtfxwtarzn.supabase.co/functions/v1/akamesmp-server-status";
    String serverToken = "";
    int intervalSeconds = 30;

    static SyncConfig load(Path path) throws IOException {
        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        if (!Files.exists(path)) {
            Files.createDirectories(path.getParent());
            Files.writeString(path, gson.toJson(new SyncConfig()));
        }
        SyncConfig c;
        try (Reader r = Files.newBufferedReader(path)) { c = gson.fromJson(r, SyncConfig.class); }
        if (c == null) throw new IOException("Leere Konfiguration");
        String env = System.getenv("AKAMESMP_SERVER_TOKEN");
        if (env != null && !env.isBlank()) c.serverToken = env;
        URI uri = URI.create(c.endpoint);
        if (!"https".equals(uri.getScheme()) || uri.getHost() == null || uri.getUserInfo() != null || uri.getFragment() != null)
            throw new IOException("endpoint muss eine HTTPS-URL sein");
        if (c.intervalSeconds < 10 || c.intervalSeconds > 60)
            throw new IOException("intervalSeconds muss zwischen 10 und 60 liegen");
        if (c.serverToken == null || c.serverToken.isBlank())
            throw new IOException("Server-Token fehlt: AKAMESMP_SERVER_TOKEN oder config/akamesmp-stats.json setzen und Server neu starten.");
        return c;
    }
}
