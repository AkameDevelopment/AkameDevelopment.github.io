package de.akame.stats;

import com.google.gson.*;
import java.io.*;
import java.nio.file.*;
import java.time.Instant;
import java.util.*;

final class StatsData {
    record Player(String player_uuid, String player_name, long playtime_seconds,
                  long player_kills, long deaths, long mob_kills, long blocks_mined,
                  long distance_walked_cm, String last_seen_at) {}
    record Payload(int online_count, int max_players, int peak_online_players,
                   long uptime_seconds, List<Player> players) {}

    static Player fromJson(UUID id, String name, JsonObject root, Instant seen) {
        JsonObject stats = object(root, "stats"), custom = object(stats, "minecraft:custom");
        return new Player(id.toString(), name, value(custom, "minecraft:play_time") / 20,
            value(custom, "minecraft:player_kills"), value(custom, "minecraft:deaths"),
            value(custom, "minecraft:mob_kills"), sum(object(stats, "minecraft:mined")),
            value(custom, "minecraft:walk_one_cm"), seen.toString());
    }
    private static JsonObject object(JsonObject parent, String key) {
        return parent.has(key) && parent.get(key).isJsonObject() ? parent.getAsJsonObject(key) : new JsonObject();
    }
    private static long value(JsonObject o, String key) {
        if (!o.has(key)) return 0;
        long n = o.get(key).getAsBigDecimal().longValueExact();
        if (n < 0 || n > 9_007_199_254_740_991L) throw new IllegalArgumentException("Invalid statistic counter");
        return n;
    }
    private static long sum(JsonObject o) {
        long n = 0;
        for (String key : o.keySet()) n = Math.addExact(n, value(o, key));
        return n;
    }
    static List<Player> collect(Path statsDir, Path usercache, Map<UUID, Player> live) throws IOException {
        return collect(List.of(statsDir), usercache, live);
    }
    static List<Player> collect(List<Path> statsDirs, Path usercache, Map<UUID, Player> live) throws IOException {
        Map<UUID, String> names = new HashMap<>();
        if (Files.exists(usercache)) {
            try (Reader reader = Files.newBufferedReader(usercache)) {
                for (JsonElement entry : JsonParser.parseReader(reader).getAsJsonArray()) {
                    JsonObject p = entry.getAsJsonObject();
                    names.put(UUID.fromString(p.get("uuid").getAsString()), p.get("name").getAsString());
                }
            }
        }
        Map<UUID, Player> all = new TreeMap<>();
        // Prefer the current Minecraft folder; legacy data only fills missing UUIDs.
        for (Path statsDir : statsDirs.stream().map(p -> p.toAbsolutePath().normalize()).distinct().toList()) {
        if (Files.isDirectory(statsDir)) {
            try (DirectoryStream<Path> files = Files.newDirectoryStream(statsDir, "*.json")) {
                for (Path file : files) {
                    String filename = file.getFileName().toString();
                    UUID id;
                    try { id = UUID.fromString(filename.substring(0, filename.length() - 5)); }
                    catch (IllegalArgumentException e) { continue; }
                    if (live.containsKey(id) || all.containsKey(id)) continue;
                    try (Reader reader = Files.newBufferedReader(file)) {
                        all.put(id, fromJson(id, names.getOrDefault(id, id.toString().substring(0, 8)),
                            JsonParser.parseReader(reader).getAsJsonObject(), Files.getLastModifiedTime(file).toInstant()));
                    } catch (RuntimeException e) {
                        throw new IOException("Statistikdatei konnte nicht gelesen werden: " + file.getFileName(), e);
                    }
                }
            }
        }
        }
        all.putAll(live);
        if (all.size() > 1000) throw new IOException("Die Website-Schnittstelle unterstützt maximal 1000 Spieler pro Übertragung.");
        return List.copyOf(all.values());
    }
}
