package de.akame.stats;

import com.google.gson.*;
import net.fabricmc.api.DedicatedServerModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.stats.Stats;
import net.minecraft.world.level.storage.LevelResource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.net.URI;
import java.net.http.*;
import java.nio.file.*;
import java.time.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;

public final class AkameStatsMod implements DedicatedServerModInitializer {
    private static final Logger LOG = LoggerFactory.getLogger("akamesmp-stats");
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private final ExecutorService worker = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "AkameSMP Stats Sync"); t.setDaemon(true); return t;
    });
    private final AtomicBoolean busy = new AtomicBoolean();
    private final HttpClient http = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(8))
        .followRedirects(HttpClient.Redirect.NEVER).build();
    private SyncConfig config;
    private long started, nextSync;
    private int peak;
    private Path peakFile;

    @Override public void onInitializeServer() {
        try { config = SyncConfig.load(FabricLoader.getInstance().getConfigDir().resolve("akamesmp-stats.json")); }
        catch (Exception e) { LOG.error("AkameSMP-Synchronisierung deaktiviert: {}", e.getMessage()); return; }
        ServerLifecycleEvents.SERVER_STARTED.register(server -> {
            started = System.nanoTime();
            peakFile = server.getWorldPath(LevelResource.ROOT).resolve("akamesmp-stats-peak.json");
            try {
                if (Files.exists(peakFile)) peak = JsonParser.parseString(Files.readString(peakFile)).getAsJsonObject().get("peak_online_players").getAsInt();
                peak = Math.max(0, peak);
            } catch (Exception e) { LOG.warn("Gespeicherter Spielerrekord konnte nicht gelesen werden."); }
            nextSync = 0;
            LOG.info("AkameSMP Stats Sync aktiv, Intervall {} Sekunden.", config.intervalSeconds);
        });
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            peak = Math.max(peak, server.getPlayerList().getPlayerCount());
            long now = System.nanoTime();
            if (now >= nextSync && busy.compareAndSet(false, true)) {
                nextSync = now + TimeUnit.SECONDS.toNanos(config.intervalSeconds);
                submit(server, false);
            }
        });
        ServerLifecycleEvents.SERVER_STOPPING.register(server -> {
            // A final snapshot is queued behind any request already running.
            submit(server, true);
            worker.shutdown();
            try { if (!worker.awaitTermination(40, TimeUnit.SECONDS)) worker.shutdownNow(); }
            catch (InterruptedException e) { worker.shutdownNow(); Thread.currentThread().interrupt(); }
        });
    }

    private void submit(MinecraftServer server, boolean stopping) {
        Map<UUID, StatsData.Player> live = new HashMap<>();
        Instant seen = Instant.now();
        for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            var s = player.getStats();
            long mined = 0;
            for (var block : net.minecraft.core.registries.BuiltInRegistries.BLOCK)
                mined += s.getValue(Stats.BLOCK_MINED, block);
            live.put(player.getUUID(), new StatsData.Player(player.getUUID().toString(), player.getGameProfile().name(),
                s.getValue(Stats.CUSTOM, Stats.PLAY_TIME) / 20L,
                s.getValue(Stats.CUSTOM, Stats.PLAYER_KILLS), s.getValue(Stats.CUSTOM, Stats.DEATHS),
                s.getValue(Stats.CUSTOM, Stats.MOB_KILLS), mined,
                s.getValue(Stats.CUSTOM, Stats.WALK_ONE_CM), seen.toString()));
        }
        Path stats = server.getWorldPath(LevelResource.ROOT).resolve("stats");
        Path usercache = FabricLoader.getInstance().getGameDir().resolve("usercache.json");
        int online = stopping ? 0 : live.size(), max = server.getMaxPlayers(), snapshotPeak = peak;
        long uptime = TimeUnit.NANOSECONDS.toSeconds(System.nanoTime() - started);
        worker.submit(() -> {
            try {
                // Persist before networking, so transient network failures don't lose the record.
                Path tmp = peakFile.resolveSibling("akamesmp-stats-peak.json.tmp");
                Files.writeString(tmp, "{\"peak_online_players\":" + snapshotPeak + "}");
                try { Files.move(tmp, peakFile, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
                catch (AtomicMoveNotSupportedException e) { Files.move(tmp, peakFile, StandardCopyOption.REPLACE_EXISTING); }
                var payload = new StatsData.Payload(online, max, snapshotPeak, uptime, StatsData.collect(stats, usercache, live));
                String body = GSON.toJson(payload);
                if (body.getBytes(java.nio.charset.StandardCharsets.UTF_8).length > 1_000_000)
                    throw new IllegalStateException("Statistikdaten überschreiten das API-Limit von 1 MB");
                var request = HttpRequest.newBuilder(URI.create(config.endpoint)).timeout(Duration.ofSeconds(15))
                    .header("Authorization", "Bearer " + config.serverToken).header("Content-Type", "application/json")
                    .POST(HttpRequest.BodyPublishers.ofString(body)).build();
                var response = http.send(request, HttpResponse.BodyHandlers.ofString());
                if (response.statusCode() != 200) {
                    LOG.warn("Statistik-Sync fehlgeschlagen (HTTP {}). Token, Schnittstelle und Serverlog prüfen. Nächster Versuch beim nächsten Intervall.", response.statusCode());
                } else {
                    JsonObject result = JsonParser.parseString(response.body()).getAsJsonObject();
                    if (!result.has("ok") || !result.get("ok").getAsBoolean())
                        LOG.warn("Statistik-Schnittstelle hat die Übertragung nicht bestätigt.");
                    else LOG.debug("Statistiken synchronisiert: {} Spieler.", payload.players().size());
                }
            } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
            catch (Exception e) { LOG.warn("Statistik-Sync fehlgeschlagen ({}). Nächster Versuch beim nächsten Intervall.", e.getClass().getSimpleName()); }
            finally { busy.set(false); }
        });
    }
}
