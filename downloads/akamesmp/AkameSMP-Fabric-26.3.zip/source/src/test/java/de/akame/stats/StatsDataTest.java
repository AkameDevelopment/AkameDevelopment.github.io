package de.akame.stats;
import com.google.gson.JsonParser;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import java.nio.file.*;
import java.time.Instant;
import java.util.*;
import static org.junit.jupiter.api.Assertions.*;
class StatsDataTest {
    @TempDir Path dir;
    final UUID id = UUID.fromString("40a56846-634b-44c9-a65f-69abc56f8288");
    final Instant seen = Instant.parse("2026-11-14T00:00:00Z");
    @Test void convertsTicksAndSumsEveryBlockType() {
        var p = StatsData.fromJson(id,"Akame",JsonParser.parseString("""
        {"stats":{"minecraft:custom":{"minecraft:play_time":72001,"minecraft:player_kills":3,"minecraft:deaths":4,"minecraft:mob_kills":50,"minecraft:walk_one_cm":123456},"minecraft:mined":{"minecraft:stone":20,"minecraft:dirt":7}}}
        """).getAsJsonObject(),seen);
        assertEquals(3600,p.playtime_seconds()); assertEquals(27,p.blocks_mined());
        assertEquals(123456,p.distance_walked_cm()); assertEquals(3,p.player_kills());
        assertEquals(4,p.deaths()); assertEquals(50,p.mob_kills());
    }
    @Test void retainsOfflinePlayersAndPrefersLiveValues() throws Exception {
        Path stats = Files.createDirectory(dir.resolve("stats")), cache=dir.resolve("usercache.json");
        Files.writeString(stats.resolve(id+".json"),"{\"stats\":{\"minecraft:custom\":{\"minecraft:deaths\":2}}}");
        Files.writeString(cache,"[{\"uuid\":\""+id+"\",\"name\":\"Akame\"}]");
        var offline=StatsData.collect(stats,cache,Map.of());
        assertEquals(1,offline.size()); assertEquals("Akame",offline.getFirst().player_name());
        assertEquals(2,offline.getFirst().deaths());
        var live=new StatsData.Player(id.toString(),"AkameNew",1,2,5,4,5,6,seen.toString());
        assertEquals(List.of(live),StatsData.collect(stats,cache,Map.of(id,live)));
    }
    @Test void refusesCorruptStatsInsteadOfPublishingPartialTotals() throws Exception {
        Path stats=Files.createDirectory(dir.resolve("stats"));
        Files.writeString(stats.resolve(id+".json"),"not-json");
        assertThrows(java.io.IOException.class,()->StatsData.collect(stats,dir.resolve("missing.json"),Map.of()));
    }
    @Test void handlesNewPlayersAndRejectsNegativeCounters() {
        var p=StatsData.fromJson(id,"Akame",JsonParser.parseString("{}").getAsJsonObject(),seen);
        assertEquals(0,p.playtime_seconds()); assertEquals(0,p.blocks_mined());
        assertThrows(IllegalArgumentException.class,()->StatsData.fromJson(id,"Akame",JsonParser.parseString("{\"stats\":{\"minecraft:custom\":{\"minecraft:deaths\":-1}}}").getAsJsonObject(),seen));
    }

    @Test void readsMinecraft263FolderAndLegacyPlayersWithoutDoubleCounting() throws Exception {
        Path current=Files.createDirectories(dir.resolve(net.minecraft.world.level.storage.LevelResource.PLAYER_STATS_DIR.id()));
        assertEquals(dir.resolve("players/stats"),current);
        Path legacy=Files.createDirectories(dir.resolve("stats"));
        UUID old=UUID.fromString("2048b050-b701-4f9f-9321-a1f0dca6963f");
        Files.writeString(current.resolve(id+".json"),"{\"stats\":{\"minecraft:custom\":{\"minecraft:deaths\":7}}}");
        Files.writeString(legacy.resolve(id+".json"),"{\"stats\":{\"minecraft:custom\":{\"minecraft:deaths\":2}}}");
        Files.writeString(legacy.resolve(old+".json"),"{\"stats\":{\"minecraft:custom\":{\"minecraft:deaths\":4}}}");
        var list=StatsData.collect(List.of(current,legacy,current.resolve(".")),dir.resolve("usercache.json"),Map.of());
        assertEquals(2,list.size());
        assertEquals(7,list.stream().filter(p->p.player_uuid().equals(id.toString())).findFirst().orElseThrow().deaths());
        var live=new StatsData.Player(id.toString(),"Akame",1,0,9,0,0,0,seen.toString());
        var withLive=StatsData.collect(List.of(current,legacy),dir.resolve("usercache.json"),Map.of(id,live));
        assertEquals(2,withLive.size());
        assertEquals(live,withLive.stream().filter(p->p.player_uuid().equals(id.toString())).findFirst().orElseThrow());
    }
}
